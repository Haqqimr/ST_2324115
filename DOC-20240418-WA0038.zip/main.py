# Contoh kode dengan berbagai tipe data variabel

# Integer
umur = 19

# Float
berat_badan = 55
nama = "Zainul Haqqi Mr"

# Boolean
sudah_menikah = False

# Output untuk memeriksa nilai variabel
print("Nama:", nama)
print("Umur:", umur)
print("Berat Badan:", berat_badan)
print("Sudah Menikah:", sudah_menikah)
